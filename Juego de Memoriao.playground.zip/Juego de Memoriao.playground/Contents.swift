//: Playground - noun: a place where people can play
// Proyecto Juego de Memoria
// Curso de Swift
// Autor: Hector Valdez Castro

import UIKit

for rango in 0...100 {
  
    if rango > 0 {
    
      if rango%5 == 0 {
          print("# \(rango) Bingo!!!")
        }
        if rango%2 == 0 {
            print("# \(rango) par!!!")
        }
        if rango%2 > 0 {
            print("# \(rango) impar!!!")
        }
        if rango >= 30 && rango <= 40 {
            print("# \(rango) Viva Swift!!!")
        }
    }
    else {print("# \(rango)")}
    
    //print("El número es: \(rango)")
}


