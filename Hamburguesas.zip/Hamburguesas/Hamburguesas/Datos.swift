//
//  Datos.swift
//  Hamburguesas
//
//  Created by Hector Valdez Castro on 13/08/16.
//  Copyright © 2016 Hector Valdez Castro. All rights reserved.
//

import Foundation
import UIKit

class ColeccionDePaises {
    
    let paises : [String] = ["Argentina","Urugual",
                             "Paraguay","Brasil","Colombia","Venezuela",
    "Mexico","Costa Rica","Uruguay","Ecuador","Panama",
    "España","Portugal","Francia","Inglaterra",
    "Italia","Alemania",
    "Grecia","Holanda","Canada","Rusia",
    "Japon","Korea","China"]
    
    
    func obtenPais()->String {
        
        let posicion = Int(arc4random_uniform(UInt32(paises.count)))
        
        return paises[posicion]
        
    }
}



class ColeccionDeHamburguesa {
    
    let hamburguesas : [String] = ["Famous","Doble",
                             "Triple","Hawaiana","Jardinera","Honga",
                             "Bigmac","Western","Classic","Oldtimer","Bigking",
                             "Whopper","Cheese Burger","Bacon Burger","Salchi Burger",
                             "Mega XT","Super Star",
                             "Guacamole Burger","ThickBurger","Chiken Burger","Onion Burger",
                             "SuperMega Burger"]

    func obtenHamburguesa()->String {
        
        let posicion = Int(arc4random_uniform(UInt32(hamburguesas.count)))
        
        return hamburguesas[posicion]
            
    }
    
}
