//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Hector Valdez Castro on 13/08/16.
//  Copyright © 2016 Hector Valdez Castro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    
    @IBOutlet weak var hamburguesaActual: UILabel!
    @IBOutlet weak var paisActual: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    let paises = ColeccionDePaises()
    let hamburguesas = ColeccionDeHamburguesa()
    
    
    @IBAction func botonQuieroHamburguesa() {
        var paisSeleccionado: String
        var hamburguesaSeleccionada: String
        
        paisSeleccionado = paises.obtenPais()
        hamburguesaSeleccionada = hamburguesas.obtenHamburguesa()
        
        hamburguesaActual.text = hamburguesaSeleccionada
        paisActual.text = paisSeleccionado
 
    }
    
 }

